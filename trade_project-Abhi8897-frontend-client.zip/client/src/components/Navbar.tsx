import { Link, NavLink, useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import { useEffect, useState } from 'react';

type User = { _id: string; firstName: string; lastName: string; email: string } | null;

export function Navbar() {
  const [user, setUser] = useState<User>(null);
  const navigate = useNavigate();

  useEffect(() => {
    api.me().then((m) => setUser(m.user)).catch(() => setUser(null));
  }, []);

  async function onLogout() {
    await api.logout();
    setUser(null);
    navigate('/login');
  }

  return (
    <div className="nav">
      <div className="brand">
        <Link to="/games">TradeApp</Link>
        <span className="badge">React + TS</span>
      </div>

      <div className="navlinks">
        <NavLink className="btn" to="/games">Games</NavLink>
        <NavLink className="btn" to="/profile">Profile</NavLink>
        {!user ? (
          <NavLink className="btn primary" to="/login">Login</NavLink>
        ) : (
          <button className="btn danger" onClick={onLogout}>Logout</button>
        )}
      </div>
    </div>
  );
}
