const express = require('express');
const controller = require('../controllers/userController');
const {isGuest, authenticated} = require('../middlewares/auth');
const {logInLimiter} = require('../middlewares/rateLimiters'); 
const {validateId, validateSignUp, validateLogIn, validateResult} = require('../middlewares/validator');

const router = express.Router();

router.get('/login', isGuest, controller.login);

router.post('/login', logInLimiter,isGuest, validateLogIn, validateResult, controller.authenticate);

router.get('/signup',isGuest, controller.signup);

router.post('/signup',isGuest, validateSignUp, validateResult, controller.create);

router.get('/game/:id', validateId, controller.selectitem);

router.post('/game/offer/:id', validateId, controller.createoffer);

router.post('/canceloffer/:id', authenticated, controller.canceloffer);

router.post('/manageoffer/:id', authenticated, controller.manageoffer);

router.post('/acceptoffer/:id', authenticated, controller.acceptoffer);

router.get('/profile', authenticated, controller.profile);

router.get('/logout', authenticated, controller.logout);

module.exports = router;