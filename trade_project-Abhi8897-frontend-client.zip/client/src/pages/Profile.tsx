import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import type { MeResponse } from '../api/types';

export default function Profile() {
  const [me, setMe] = useState<MeResponse>({ user: null, watchlist: [] });
  const [status, setStatus] = useState<'loading'|'ready'|'error'>('loading');

  useEffect(() => {
    setStatus('loading');
    api.me()
      .then((m) => { setMe(m as MeResponse); setStatus('ready'); })
      .catch(() => setStatus('error'));
  }, []);

  if (status === 'loading') {
    return (
      <div className="grid">
        <div className="card" style={{ gridColumn: 'span 12' }}>
          <div className="row"><div className="spinner" /><div className="muted">Loading…</div></div>
        </div>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="grid">
        <div className="card" style={{ gridColumn: 'span 12' }}>
          <div style={{fontWeight: 800}}>Couldn’t load profile.</div>
          <div className="muted">Check server connection.</div>
        </div>
      </div>
    );
  }

  return (
    <div className="grid">
      <div className="card" style={{ gridColumn: 'span 5' }}>
        <div className="h1" style={{marginTop: 0}}>Profile</div>
        {me.user ? (
          <>
            <div style={{fontWeight: 800}}>{me.user.firstName} {me.user.lastName}</div>
            <div className="muted">{me.user.email}</div>
          </>
        ) : (
          <>
            <div style={{fontWeight: 800}}>Not logged in</div>
            <div className="muted">Login to see your watchlist.</div>
            <div style={{marginTop: 12}}><Link className="btn primary" to="/login">Go to login</Link></div>
          </>
        )}
      </div>

      <div className="card" style={{ gridColumn: 'span 7' }}>
        <div style={{fontWeight: 800, fontSize: 16}}>Watchlist</div>
        <div className="muted">{me.watchlist.length} item(s)</div>

        <div style={{ marginTop: 12, display: 'grid', gap: 10 }}>
          {me.watchlist.map((w) => (
            <Link key={w._id} to={'/games/' + w._id} className="btn" style={{ justifyContent: 'space-between' }}>
              <span>{w.Name}</span>
              <span className="badge">{w.Status || 'unknown'}</span>
            </Link>
          ))}
          {me.watchlist.length === 0 && <div className="muted">No items saved yet.</div>}
        </div>
      </div>
    </div>
  );
}
