const game = require('../models/game');

exports.isGuest = (req,res,next)=>{
    if(!req.session.user){
         return next();
         }else{
             req.flash('error', 'Already logged in');
             return res.redirect('/users/profile');
         }
}


exports.authenticated = (req,res,next)=>{
    if(req.session.user){
        return next();
    }else{
        req.flash('error', 'You need to login first!');
        res.redirect('/users/login');
    }
};


exports.isCreatedBy = (req,res,next)=>{
    id = req.params.id;
    game.findById(id)
    .then((game)=>{ 
        if(game){
            if(game.CreatedBy==req.session.user){
                return next();
            }else{
                let err= new Error ("Not authorized to access the resource");
                err.status =401;
                next(err);
            }
        }
    })
    .catch(err=>{
        next(err);
    })
};