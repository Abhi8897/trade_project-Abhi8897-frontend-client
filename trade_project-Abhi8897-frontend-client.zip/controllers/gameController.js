const model=require('../models/game');
const { route } = require('../routes/gameRoutes');
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;
const User = require('../models/user');
const Offer = require('../models/offer');


exports.index=(req,res)=>{
    model.find().lean()
    .then((games)=>{
        res.render('./trade/trades',{games});
    })
    .catch((err)=>{
        next(err);
    })
};

exports.new=(req,res)=>{
    res.render('./trade/newTrade');
}

exports.create=(req,res,next)=>{
    
    // let newGame= model(req.body);
    const newGame = new model({
        Name: req.body.Name,
        Category: req.body.Category,
        Details: req.body.Details,
        Seller: req.body.Seller,
        Released: req.body.Released,
        CreatedBy : req.session.user,
        Status: "available"
          })
    newGame.save()
    .then(()=>{
        res.redirect('/games');
    })
    .catch(err=>{
        if(err.name === 'ValidationError'){
            err.status = 402;
        }
        next(err);
    });
}

exports.show=(req,res,next)=>{
    let id=req.params.id;
    model.findById(id).populate('CreatedBy', 'firstName lastName').lean()
        .then(game => {
            if (game) {
                return res.render('./trade/trade', { game });
            } else {
                let err = new Error('Cannot find a game with ID ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));   
}

exports.edit=(req,res,next)=>{
    // res.send("form for edit");
    let id=req.params.id;
    model.findById(id).lean()
        .then((game) => {
            if (game) {
                return res.render('./trade/editTrade', {game});
            } else {
                let err = new Error('Cannot find a game with ID ' + id);
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));

}

exports.update=(req,res,next)=>{
    let game=req.body;
    let id=req.params.id;
    model.findByIdAndUpdate(id, game, { useFindAndModify: false, runValidators: true }).lean()
    .then((game) => {

        if (game) {
            res.redirect('/games/' + id);
        } else {
            let err = new Error('Cannot find the updated game details ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err => {
        if (err.name === 'ValidationError')
            err.status = 402;
        next(err);
    });
}

exports.delete = (req, res, next) => {
    let id = req.params.id;
    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(game => {
        if(game && (game.Status == "available")){
            res.redirect('/games');
        }
        else if(game && (game.Status != "traded")){
            if(game.OfferedTo == id){
                Offer.find({OfferedTo: id})
                .then(offer => {
                    model.findByIdAndUpdate(offer[0].ItemToTrade, {Status: 'available', Offered: false, Initiated: false}, {useFindAndModify: false, runValidators: true})
                    .then(updated_trade => {
                        Offer.findOneAndDelete({OfferedTo: id}, {useFindAndModify: false})
                        .then(updated_trade => {
                            res.redirect('/games');
                        })
                        .catch(err => next(err));
                    })
                    .catch(err => next(err));
                })
                .catch(err => next(err));
            }
            else if(game.OfferBy == id){
                Offer.find({ItemToTrade: id})
                .then(offer => {
                    model.findByIdAndUpdate(offer[0].OfferedTo, {Status: 'available', Offered: false, Initiated: false}, {useFindAndModify: false, runValidators: true})
                    .then(trade => {
                        Offer.findOneAndDelete({ItemToTrade: id}, {useFindAndModify: false})
                        .then(offer => {
                            res.redirect('/games');
                        })
                        .catch(err => next(err));
                    })
                    .catch(err => next(err));
                })
                .catch(err => next(err));
            }
        }
        else if(game && (game.Status == "traded")){
            if(game.OfferBy == id){
                model.findByIdAndUpdate(game.OfferTo, {Status: 'available', Offered: false, Initiated: false}, {useFindAndModify: false, runValidators: true})
                .then(updated_trade => {
                    res.redirect('/games');
                })
                .catch(err => next(err));
            }
            else if(game.OfferTo == id){
                model.findByIdAndUpdate(game.OfferBy, {Status: 'available', Offered: false, Initiated: false}, {useFindAndModify: false, runValidators: true})
                .then(trade => {
                    res.redirect('/games');
                })
                .catch(err => next(err));
            }
        }
        else{
            res.redirect('/games');
        }
    })
    .catch(err => next(err));
};

exports.addtowatchlist = (req, res, next) => {
    let id = req.params.id;
    let user = req.session.user;
    User.findByIdAndUpdate(user, {$push: {watchlist: id}}, {useFindAndModify: false, runValidators: true})
    .then(user => {
        if(user){
            req.flash('success', 'Game added to watchlist successfully'); 
            res.redirect('../../users/profile');
        }
        else
            res.redirect('/users/login');
    })
    .catch(err => next(err));
};

exports.deletefromwatchlist = (req, res, next) => {
    let id = req.params.id;
    let user = req.session.user;
    User.findByIdAndUpdate(user, {$pull: {watchlist: id}}, {useFindAndModify: false, runValidators: true})
    .then(user => {
        if(user)
            req.flash('success', 'Game removed from watchlist successfully'); 
            res.redirect('back');
    })
    .catch(err => next(err));
};