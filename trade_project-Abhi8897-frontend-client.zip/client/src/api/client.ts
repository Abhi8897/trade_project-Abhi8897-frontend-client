export type ApiError = { error: string; details?: unknown };

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(init.headers ?? {})
    },
    credentials: 'include'
  });

  if (!res.ok) {
    let body: any = null;
    try { body = await res.json(); } catch {}
    const msg = body?.error ?? `HTTP_${res.status}`;
    throw Object.assign(new Error(msg), { status: res.status, body });
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

export const api = {
  games: () => request<{ games: any[] }>('/api/games'),
  game: (id: string) => request<{ game: any }>('/api/games/' + id),
  me: () => request<{ user: any | null; watchlist: any[] }>('/api/me'),
  login: (email: string, password: string) =>
    request<{ user: any }>('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  logout: () => request<void>('/api/auth/logout', { method: 'POST' }),
  watch: (id: string) => request<{ ok: true }>('/api/games/' + id + '/watch', { method: 'POST' }),
  unwatch: (id: string) => request<{ ok: true }>('/api/games/' + id + '/unwatch', { method: 'POST' })
};
