import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, Navigate, RouterProvider } from 'react-router-dom';
import App from './App';
import './styles.css';

import GamesList from './pages/GamesList';
import GameDetail from './pages/GameDetail';
import Login from './pages/Login';
import Profile from './pages/Profile';

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { index: true, element: <Navigate to="/games" replace /> },
      { path: 'games', element: <GamesList /> },
      { path: 'games/:id', element: <GameDetail /> },
      { path: 'login', element: <Login /> },
      { path: 'profile', element: <Profile /> }
    ]
  }
]);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
