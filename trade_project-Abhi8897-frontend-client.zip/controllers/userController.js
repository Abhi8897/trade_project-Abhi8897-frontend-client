const user = require('../models/user');
const game = require('../models/game');
const Offer = require('../models/offer');



exports.login = (req,res)=>{
    res.render('./user/login');
};

exports.authenticate = (req,res,next)=>{
     let email = req.body.email;
     let password = req.body.password;
       user.findOne({email:email})
     .then((user)=>{
         if(user){
             user.comparePassword(password)
             .then((result)=>{
                 if(result){
                     req.session.user = user._id;
                     req.flash('success', 'Logged in successfully');
                   res.redirect('/users/profile');  
                 }else{
                     req.flash('error', 'wrong password');
                     res.redirect('/users/login');
                 }
             })
         }else{
            req.flash('error','Invalid Email'); 
            res.redirect('/users/login');
         }
     })
     .catch((err)=>{
         next(err);
     });
}

exports.signup = (req,res)=>{
    res.render('./user/signup');
};

exports.create = (req,res,next)=>{
    let body = new user(req.body);
    body.save()
    .then(()=>{
        req.flash('success', 'Registration succeeded!');
        res.redirect('/users/login');
    })
  .catch(err=>{
      if(err.name==='ValidationError'){
          req.flash('error', err.message);
          return res.redirect('/users/signup');
      }
      if(err.code===11000){
          req.flash('error','Email has already been used');
          res.redirect('/users/signup');
      }
    next(err);
  })
}


exports.profile=(req,res,next)=>{
    let id = req.session.user;
   Promise.all([user.findById(id), game.find({CreatedBy:id}), Offer.find({OfferedBy: id})])
    .then((results)=>{
        const [user, games, offers] = results;
        game.find({'_id':{$in:user.watchlist}})
        .then(watchlist => {
            res.render('./user/profile', {user, games, watchlist, offers});
        })
        .catch(err => next(err));
    })
    .catch((err)=>{
        next(err);
    })
}

exports.logout = (req,res,next)=>{
    req.session.destroy(err=>{
        if(err)
        return next(err);
        else
        res.redirect('/');
    })
}

exports.selectitem = (req, res, next) => {
    let id = req.params.id;
    game.find({CreatedBy: req.session.user})
    .then(games => {
        if(games.length > 0)
            res.render('./user/trade', {games, id});
        else{
            req.flash('error', "You don't have any games to trade");      
            res.redirect('back');
        }
    })
    .catch(err => next(err));
};

exports.createoffer = (req, res, next) => {
    let id = req.params.id; 
    let user_item = req.body.item; 
    Promise.all([
        game.findByIdAndUpdate(id, {Status: "offer pending", OfferBy: user_item, OfferTo: id, Offered: true}, {useFindAndModify: false, runValidators: true}),
        game.findByIdAndUpdate(user_item, {Status: "offer pending",  OfferTo: id, OfferBy: user_item, Initiated: true}, {useFindAndModify: false, runValidators: true})])
    .then(results => {
        let [game, user_trade] = results;
        let offer = new Offer();
        offer.OfferedBy = req.session.user;
        offer.Title = game.Name;
        offer.Category = game.Category;
        offer.Status = game.Status;
        offer.ItemToTrade = user_item;
        offer.OfferedTo = id;
        offer.save()
        .then(offer => {
            res.redirect('/users/profile');
        })
        .catch(err => next(err));
    })
    .catch(err => next(err));
};

exports.canceloffer = (req, res, next) => {
    let id = req.session.user;
    let item = req.params.id;
    Offer.findOneAndDelete({OfferedTo: item}, {useFindAndModify: false})
    .then(offer => {
        game.findByIdAndUpdate(item, {Status: 'available', Offered: false, Initiated: false}, {useFindAndModify: false, runValidators: true})
        .then(trade => {
            game.findByIdAndUpdate(trade.OfferedBy, {Status: 'available', Offered: false, Initiated: false}, {useFindAndModify: false, runValidators: true})
            .then(trade => {
                res.redirect('/users/profile');
            })
        })
        .catch(err => next(err));
    })
    .catch(err => next(err));
};

exports.manageoffer = (req, res, next) => {
    let id = req.params.id;
    game.findById(id)
    .then(game1 => {
        if(!game1.Offered){
            Offer.find({ItemToTrade: id})
            .then(offer => {
                if(offer.length > 0){
                    Promise.all([game.findById(offer[0].OfferedTo), game.findById(offer[0].ItemToTrade)])
                    .then(results => {
                        let [game, item] = results;
                        let initiated = item.Initiated;
                        res.render('./user/manageoffer', {game, item, initiated});
                    })
                    .catch(err => next(err));
                }
                else{
                    let err = new Error('Cannot find an offer');
                    err.status = 404;
                    next(err);
                }
            })
            .catch(err => next(err));
        }
        else{
            Offer.find({OfferedTo: id})
            .then(offer => {
                if(offer.length > 0){
                    Promise.all([game.findById(offer[0].OfferedTo), game.findById(offer[0].ItemToTrade)])
                    .then(results => {
                        let [game, item] = results;
                        let initiated = game.Initiated;
                        res.render('./user/manageoffer', {game, item, initiated});
                    })
                    .catch(err => next(err));
                }
                else{
                    let err = new Error('Cannot find an offer');
                    err.status = 404;
                    next(err);
                }
            })
            .catch(err => next(err));
        }
    })
    .catch(err => next(err));

    
};

exports.acceptoffer = (req, res, next) => {
    let id = req.session.user;
    let item = req.params.id;
    Offer.find({OfferedTo: item, OfferedBy: id}, {useFindAndModify: false})
    .then(offer => {
        game.findByIdAndUpdate(item, {Status: 'traded', Intitiated: false, Offered: false}, {useFindAndModify: false, runValidators: true})
        .then(trade => {
            game.findByIdAndUpdate(trade.OfferBy, {Status: 'traded', Initiated: false, Offered: false}, {useFindAndModify: false, runValidators: true})
            .then(trade => {
                Offer.findOneAndDelete({OfferedTo: item}, {useFindAndModify: false})
                .then(offer => {
                    res.redirect('/users/profile');
                })
                .catch(err => next(err));
            })
        })
        .catch(err => next(err));
    })
    .catch(err => next(err));
};



