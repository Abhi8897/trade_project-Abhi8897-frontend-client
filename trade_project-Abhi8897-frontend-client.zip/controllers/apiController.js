const Game = require('../models/game');
const User = require('../models/user');
const bcrypt = require('bcrypt');

/**
 * Small JSON API to support the React client (client/).
 * Notes:
 * - Session auth is reused (express-session). Client must send cookies with requests.
 * - Keep responses intentionally minimal (good for frontend interviews).
 */

function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'UNAUTHENTICATED' });
  }
  next();
}

exports.listGames = async (req, res, next) => {
  try {
    const games = await Game.find().sort({ Name: 1 }).lean();
    res.json({ games });
  } catch (err) {
    next(err);
  }
};

exports.getGame = async (req, res, next) => {
  try {
    const game = await Game.findById(req.params.id).lean();
    if (!game) return res.status(404).json({ error: 'NOT_FOUND' });
    res.json({ game });
  } catch (err) {
    next(err);
  }
};

exports.me = async (req, res, next) => {
  try {
    if (!req.session || !req.session.user) {
      return res.json({ user: null, watchlist: [] });
    }
    const u = await User.findById(req.session.user).populate('watchlist').lean();
    if (!u) return res.json({ user: null, watchlist: [] });

    // do not leak password hash
    delete u.password;

    const watchlist = (u.watchlist || []).map((g) => ({
      _id: g._id,
      Name: g.Name,
      Category: g.Category,
      Status: g.Status,
      Released: g.Released,
      Seller: g.Seller,
    }));

    res.json({
      user: { _id: u._id, firstName: u.firstName, lastName: u.lastName, email: u.email },
      watchlist,
    });
  } catch (err) {
    next(err);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'EMAIL_AND_PASSWORD_REQUIRED' });

    const u = await User.findOne({ email }).exec();
    if (!u) return res.status(401).json({ error: 'INVALID_CREDENTIALS' });

    const ok = await u.comparePassword(password);
    if (!ok) return res.status(401).json({ error: 'INVALID_CREDENTIALS' });

    req.session.user = u._id;
    res.json({ user: { _id: u._id, firstName: u.firstName, lastName: u.lastName, email: u.email } });
  } catch (err) {
    next(err);
  }
};

exports.logout = async (req, res, next) => {
  try {
    if (!req.session) return res.status(204).end();
    req.session.destroy((err) => {
      if (err) return next(err);
      res.status(204).end();
    });
  } catch (err) {
    next(err);
  }
};

exports.watch = [
  requireAuth,
  async (req, res, next) => {
    try {
      const gameId = req.params.id;
      const u = await User.findById(req.session.user);
      if (!u) return res.status(401).json({ error: 'UNAUTHENTICATED' });

      const already = u.watchlist.some((id) => id.toString() === gameId);
      if (!already) {
        u.watchlist.push(gameId);
        await u.save();
      }
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  },
];

exports.unwatch = [
  requireAuth,
  async (req, res, next) => {
    try {
      const gameId = req.params.id;
      const u = await User.findById(req.session.user);
      if (!u) return res.status(401).json({ error: 'UNAUTHENTICATED' });

      u.watchlist = (u.watchlist || []).filter((id) => id.toString() !== gameId);
      await u.save();
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  },
];
