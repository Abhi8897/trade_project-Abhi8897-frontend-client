import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api/client';
import type { Game, MeResponse } from '../api/types';
import { Toast } from '../components/Toast';

export default function GameDetail() {
  const { id } = useParams();
  const [game, setGame] = useState<Game | null>(null);
  const [me, setMe] = useState<MeResponse>({ user: null, watchlist: [] });
  const [status, setStatus] = useState<'loading'|'ready'|'error'>('loading');
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    setStatus('loading');
    Promise.all([api.game(id!), api.me()])
      .then(([g, m]) => {
        setGame(g.game as Game);
        setMe(m as MeResponse);
        setStatus('ready');
      })
      .catch(() => setStatus('error'));
  }, [id]);

  const watched = useMemo(() => {
    return me.watchlist.some((w) => w._id === id);
  }, [me.watchlist, id]);

  async function toggleWatch() {
    if (!me.user) return setToast('Please login to use Watchlist.');
    if (!id) return;
    if (watched) {
      await api.unwatch(id);
      setToast('Removed from watchlist');
    } else {
      await api.watch(id);
      setToast('Added to watchlist');
    }
    const updated = await api.me();
    setMe(updated as MeResponse);
  }

  if (status === 'loading') {
    return (
      <div className="grid">
        <div className="card" style={{ gridColumn: 'span 12' }}>
          <div className="row">
            <div className="spinner" />
            <div className="muted">Loading…</div>
          </div>
        </div>
      </div>
    );
  }

  if (status === 'error' || !game) {
    return (
      <div className="grid">
        <div className="card" style={{ gridColumn: 'span 12' }}>
          <div style={{fontWeight: 800}}>Couldn’t load this game.</div>
          <div className="muted">Try going back to the list.</div>
          <div style={{ marginTop: 12 }}><Link className="btn" to="/games">← Back</Link></div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="grid">
        <div className="card" style={{ gridColumn: 'span 8' }}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <div>
              <div className="h1" style={{marginTop: 0}}>{game.Name}</div>
              <div className="muted">{game.Category} • {game.Released}</div>
            </div>
            <div className="row">
              <span className="badge">{game.Status || 'unknown'}</span>
              <span className="badge">{game.Seller}</span>
            </div>
          </div>

          <div style={{ marginTop: 14, whiteSpace: 'pre-wrap' }}>{game.Details}</div>

          <div className="row" style={{ marginTop: 18 }}>
            <button className={"btn " + (watched ? "danger" : "primary")} onClick={toggleWatch}>
              {watched ? "Unwatch" : "Add to watchlist"}
            </button>
            <Link className="btn" to="/games">Back to list</Link>
          </div>

          {!me.user && <div className="muted" style={{ marginTop: 10 }}>Login to save items to your watchlist.</div>}
        </div>

        <div className="card" style={{ gridColumn: 'span 4' }}>
          <div style={{ fontWeight: 800, fontSize: 16 }}>Your session</div>
          <div className="muted" style={{ marginTop: 6 }}>
            {me.user ? (
              <>
                Logged in as <b>{me.user.firstName}</b><br />
                <small>{me.user.email}</small>
              </>
            ) : (
              <>Not logged in</>
            )}
          </div>

          <div style={{ marginTop: 16, fontWeight: 800 }}>Watchlist</div>
          <div className="muted">{me.watchlist.length} item(s)</div>

          <div style={{ marginTop: 10, display: 'grid', gap: 8 }}>
            {me.watchlist.slice(0, 5).map((w) => (
              <Link key={w._id} to={'/games/' + w._id} className="btn" style={{ justifyContent: 'flex-start' }}>
                {w.Name}
              </Link>
            ))}
            {me.watchlist.length === 0 && <div className="muted">No saved items yet.</div>}
          </div>
        </div>
      </div>

      <Toast message={toast} onClose={() => setToast(null)} />
    </>
  );
}
