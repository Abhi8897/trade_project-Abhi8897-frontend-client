import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Proxy /api calls to the Express server so cookies work in dev.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:3005',
        changeOrigin: true
      }
    }
  }
})
