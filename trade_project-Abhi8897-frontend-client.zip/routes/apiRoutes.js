const express = require('express');
const { body, validationResult, param } = require('express-validator');
const controller = require('../controllers/apiController');

const router = express.Router();

function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ error: 'VALIDATION_ERROR', details: errors.array() });
  }
  next();
}

// Games
router.get('/games', controller.listGames);

router.get(
  '/games/:id',
  param('id').isMongoId().withMessage('Invalid id'),
  validate,
  controller.getGame
);

// Auth/session
router.get('/me', controller.me);

router.post(
  '/auth/login',
  body('email').isEmail().withMessage('Valid email required'),
  body('password').isString().isLength({ min: 1 }).withMessage('Password required'),
  validate,
  controller.login
);

router.post('/auth/logout', controller.logout);

// Watchlist
router.post(
  '/games/:id/watch',
  param('id').isMongoId().withMessage('Invalid id'),
  validate,
  controller.watch
);

router.post(
  '/games/:id/unwatch',
  param('id').isMongoId().withMessage('Invalid id'),
  validate,
  controller.unwatch
);

module.exports = router;
