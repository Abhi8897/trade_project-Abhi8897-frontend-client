const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const gameSchema = new Schema({
    Name: { type: String, required: [true, 'Game name is required'] },
    Category: { type: String, required: [true, 'Game Category topic is required'] },
    Details: { type: String, required: [true, 'Details are required'] },
    Seller: { type: String, required: [true, 'Seller is required'] },
    Status: {type: String},
    Released: { type: String, required: [true, 'Released year is required'] },
    CreatedBy: {type: String, ref:'user'},
    Author: {type:Schema.Types.ObjectId, ref: 'user'},
    OfferBy: {type: Schema.Types.ObjectId, ref: 'game'},
    OfferTo: {type: Schema.Types.ObjectId, ref: 'game'},
    Offered: {type: Boolean},
    Initiated: {type: Boolean}
});

const game = mongoose.model('game', gameSchema);
module.exports = game;
