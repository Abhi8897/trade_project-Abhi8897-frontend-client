import { useEffect } from 'react';

export function Toast({ message, onClose }: { message: string | null; onClose: () => void }) {
  useEffect(() => {
    if (!message) return;
    const t = setTimeout(onClose, 2500);
    return () => clearTimeout(t);
  }, [message, onClose]);

  if (!message) return null;

  return (
    <div className="toast" role="status" aria-live="polite">
      <div style={{fontWeight: 700, marginBottom: 4}}>Done</div>
      <div>{message}</div>
      <div style={{marginTop: 6}}><small>Auto closes in ~2.5s</small></div>
    </div>
  );
}
