import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import type { Game } from '../api/types';

export default function GamesList() {
  const [games, setGames] = useState<Game[]>([]);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState<'idle'|'loading'|'error'|'ready'>('idle');

  useEffect(() => {
    setStatus('loading');
    api.games()
      .then((r) => {
        setGames(r.games as Game[]);
        setStatus('ready');
      })
      .catch(() => setStatus('error'));
  }, []);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    const base = query
      ? games.filter((g) =>
          [g.Name, g.Category, g.Seller, g.Status, g.Released].some((v) => (v ?? '').toLowerCase().includes(query))
        )
      : games;
    return base;
  }, [games, q]);

  return (
    <>
      <div className="grid">
        <div className="card" style={{ gridColumn: 'span 12' }}>
          <div className="h1">Browse games</div>
          <div className="row" style={{ marginTop: 10 }}>
            <input
              className="input"
              placeholder="Search by name, category, seller, status..."
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <span className="kbd">⌘K</span>
            <span className="muted">Tip: type “available” to filter</span>
          </div>
          {status === 'loading' && (
            <div className="row" style={{ marginTop: 12 }}>
              <div className="spinner" />
              <div className="muted">Loading games…</div>
            </div>
          )}
          {status === 'error' && (
            <div className="row" style={{ marginTop: 12 }}>
              <div style={{ color: 'var(--danger)', fontWeight: 700 }}>Couldn’t load games.</div>
              <div className="muted">Is the server running on localhost:3005?</div>
            </div>
          )}
        </div>

        {filtered.map((g) => (
          <Link key={g._id} to={'/games/' + g._id} className="card" style={{ gridColumn: 'span 4' }}>
            <div style={{ fontWeight: 800, fontSize: 16 }}>{g.Name}</div>
            <div className="muted">{g.Category} • {g.Released}</div>
            <div style={{ marginTop: 8 }}>
              <span className="badge">{g.Status || 'unknown'}</span>
              <span className="badge" style={{ marginLeft: 8 }}>{g.Seller}</span>
            </div>
            <div className="muted" style={{ marginTop: 10 }}>View details →</div>
          </Link>
        ))}

        {status === 'ready' && filtered.length === 0 && (
          <div className="card" style={{ gridColumn: 'span 12' }}>
            <div style={{ fontWeight: 800 }}>No results</div>
            <div className="muted">Try a different search term.</div>
          </div>
        )}
      </div>
    </>
  );
}
