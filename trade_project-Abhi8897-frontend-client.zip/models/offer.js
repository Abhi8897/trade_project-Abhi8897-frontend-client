const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const offerSchema = new Schema({
    OfferedBy: {type: Schema.Types.ObjectId, ref: 'user'},
    ItemToTrade: {type: Schema.Types.ObjectId, ref: 'game'},
    Title: {type: String, required: [true, 'title is required']},
    Category: {type: String, required: [true, 'category is required']},
    Status: {type: String, required: [true, 'status is required']},
    OfferedTo: {type: Schema.Types.ObjectId, ref: 'game'}
}
);

module.exports = mongoose.model('Offer', offerSchema);