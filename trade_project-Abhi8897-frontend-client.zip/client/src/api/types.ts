export type Game = {
  _id: string;
  Name: string;
  Category: string;
  Details: string;
  Seller: string;
  Status?: string;
  Released: string;
};

export type MeResponse = {
  user: null | { _id: string; firstName: string; lastName: string; email: string };
  watchlist: Array<Pick<Game, '_id' | 'Name' | 'Category' | 'Status' | 'Released' | 'Seller'>>;
};
