const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    firstName :{type: String, required: [true, 'FirstName is required']},
    lastName :{type: String, required: [true, 'LastName is required']},
    email:{type: String, required: [true, 'Email is required'], unique: true},
    password: {type: String, required: [true, 'Password is required']},
    watchlist: [{type: Schema.Types.ObjectId, ref: 'game'}]
});


UserSchema.pre('save', function(next){
    let user = this;
    if(!user.isModified('password')){
        return next();
    }
    bcrypt.hash(user.password, 10)
    .then((hash)=>{
        user.password = hash;
        next();
    })
    .catch((err)=>{
        next(err);
    });
});

//comparing login details
UserSchema.methods.comparePassword = function (password){
    return bcrypt.compare(password, this.password);
}
const userModel = mongoose.model('user',UserSchema);
module.exports = userModel;