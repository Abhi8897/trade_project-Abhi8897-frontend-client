import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState<'idle'|'loading'|'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus('loading');
    setError(null);
    try {
      await api.login(email, password);
      navigate('/games');
    } catch (err: any) {
      setError(err?.message === 'INVALID_CREDENTIALS' ? 'Wrong email or password' : 'Login failed');
      setStatus('error');
    }
  }

  return (
    <div className="grid">
      <div className="card" style={{ gridColumn: 'span 6' }}>
        <div className="h1" style={{marginTop: 0}}>Login</div>
        <div className="muted">Use an account from your MongoDB users collection.</div>

        <form onSubmit={onSubmit} style={{ marginTop: 14, display: 'grid', gap: 10 }}>
          <div>
            <div className="muted" style={{ marginBottom: 6 }}>Email</div>
            <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@email.com" />
          </div>
          <div>
            <div className="muted" style={{ marginBottom: 6 }}>Password</div>
            <input className="input" value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="••••••••" />
          </div>

          <button className="btn primary" disabled={status === 'loading'}>
            {status === 'loading' ? 'Logging in…' : 'Login'}
          </button>

          {error && <div style={{ color: 'var(--danger)', fontWeight: 700 }}>{error}</div>}
        </form>
      </div>

      <div className="card" style={{ gridColumn: 'span 6' }}>
        <div style={{ fontWeight: 800 }}>Why this exists</div>
        <div className="muted" style={{ marginTop: 8 }}>
          This React client demonstrates frontend skills (routing, state, API integration, UI states) on top of the existing Express/MongoDB project.
        </div>

        <div style={{ marginTop: 14, fontWeight: 800 }}>API used</div>
        <div className="muted">POST /api/auth/login</div>
        <div className="muted">GET /api/me</div>

        <div style={{ marginTop: 14, fontWeight: 800 }}>Next steps</div>
        <div className="muted">Add Offers UI, form validation library, and component tests.</div>
      </div>
    </div>
  );
}
