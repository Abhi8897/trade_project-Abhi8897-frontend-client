const express=require('express');
const router=express.Router();
const controller=require('../controllers/gameController');
const {authenticated, isCreatedBy} = require('../middlewares/auth');
const {validateId} = require('../middlewares/validator');

router.get('/', controller.index);

router.get('/new',authenticated ,controller.new);

router.post('/',authenticated ,controller.create);

router.get('/:id',validateId ,controller.show);

router.get('/:id/edit',validateId,authenticated,isCreatedBy ,controller.edit);

router.put('/:id' ,validateId,authenticated ,isCreatedBy ,controller.update);

router.delete('/:id' ,validateId,authenticated ,isCreatedBy ,controller.delete);

router.post('/:id/watch', validateId, authenticated, controller.addtowatchlist);

router.post('/:id/unwatch', validateId, authenticated, controller.deletefromwatchlist);

module.exports=router;
